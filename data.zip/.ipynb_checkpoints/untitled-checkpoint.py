import json
import matplotlib.pyplot as plt

files = {
    "LoRA rank 4": results_dir / "loss_history_rank4.json",
    "LoRA rank 8": results_dir / "loss_history_rank8.json",
}

lora_losses = {}
for label, fp in files.items():
    with open(fp) as f:
        lora_losses[label] = json.load(f)

plt.figure(figsize=(10, 6))
for label, data in lora_losses.items():
    plt.plot(data["epochs"], data["losses"], marker="o", label=label)

# Styling improvements
plt.title("Loss vs Epoch for Meditron Fine-Tuning", fontsize=16)
plt.xlabel("Epoch", fontsize=14)
plt.ylabel("Training loss", fontsize=14)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.legend(fontsize=12, title_fontsize=13)
plt.grid(True)

# Save the plot
plot_path = results_dir / "loss_vs_epoch_plot.png"
plt.savefig(plot_path, dpi=300, bbox_inches="tight")
print(f"Plot saved to {plot_path}")
